local worker = require("worker")

worker.run()